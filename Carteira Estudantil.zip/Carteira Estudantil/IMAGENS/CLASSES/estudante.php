<?php

class estudante
{
    private $pdo;
    public $msgErro = "";// tudo ok

    public function conectar($nome,$host,$usuario,$senha)
    {
    global $pdo;
    try
    {
    $pdo = new PDO("mysql:dbname=".$nome.";host=".$host,$usuario,$senha);
}catch (PDOException $msgErro){
    $msgErro = "Erro de login";
    //$e ->getMessage();
}
}
    public function cadastrar($escola,$curso,$serie,$nome,$cpf,$datanasc,$email,$senha)

    {
    global $pdo;
    //verificar se já existe o email cadastrado
    $sql = $pdo->prepare("select id_estudante FROM estudante where email = :e");
    $sql->bindValue(":e",$email);
    $sql->execute();
    if($sql->rowCount() > 0)
    {
        return false; // ja esta cadastrado

    }
    else{
    }
    //caso não, cadastrar
    $sql = $pdo->prepare("INSERT INTO estudante(nome,cpf,datanasc,email,senha) VALUES (:es,cu,se,n,c,d,e,s)");
    $sql->bindValue(":es",$escola);
    $sql->bindValue(":cu",$curso);
    $sql->bindValue(":se",$serie);
    $sql->bindValue(":n",$nome);
    $sql->bindValue("c",$cpf);
    $sql->bindValue("d",$datadenasc);
    $sql->bindValue("e",$email);
    $sql->bindValue("s", md5($senha));
    $sql->execute();
    return true;
 }

    public function logar($email,$senha)
{
    global $pdo;
    //verificar se o email e senha estao cadastrados, se sim 
    $sql = $pdo ->prepare("SELECT id_estudante from usuario WHERE email = :e AND senha = :s");
    $sql->bindValue(":e",$email);
    $sql->bindValue(":s",md5($senha));
    $sql->execute();
    if($sql->rowCount() > 0)
    {

    // entrar no sistema(sessao)
    $dado = $sql->fetch();
    session_start();
    $_SESSION['id_estudante'] = $dado['id_estudante'];
    return true; //Logado com sucesso
}
else
{
    return false; //não foi possível logar

}
}

}

?>