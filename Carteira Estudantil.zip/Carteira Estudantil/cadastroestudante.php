<?php
    require_once 'IMAGENS/CLASSES/estudante.php';
    $u = new estudante();

?>
<html lang="pt-br">
<head>
    <meta charset="utf-8/">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="CSS/estilo.css">
<body>
    
    <center><h1>Cadastro de Estudante</h1></center>
    <form method="POST">
    <div align="center">
    <table border ="1" width=50% >
    <tr>
        <td><input type="text" name="nome" placeholder="Nome Completo" maxlength="100"></td>
        <td><input type="text" name="CPF" placeholder="CPF" maxlength="32"></td>
    </tr>
     <tr>
        <td><input type="text"name="usuario" placeholder="usuario" maxlength="100"></td>
        <td><input type="text" name="serie" placeholder="serie" maxlength="32"></td>
    </tr>
    <tr>
        <td><input type="text" name="escola" placeholder="escola" maxlength="32"></td>
        <td><input type="text" name="curso" placeholder="curso" maxlength="32"></td>
     </tr>
    <tr>
        <td><input type="date" name="datanasc" placeholder="Data de Nascimento" maxlength="32">
        <td><input type="text" name="email" placeholder="email" maxlength="32">
    </tr>
    <tr>
        <td><input type="password" name="senha" placeholder="Senha" maxlength="32">
        <td><input type="password" name="confSenha" placeholder="Confirmar Senha" maxlength="32">
    </tr>
    <tr>
     <td colspan="2" align="center"><input type="submit" value="Cadastrar"></td>
   </tr>
   <tr> 
   <td colspan="2" align="center">  <a href="menu/menu.php"> voltar ao menu</a></td>
</tr>
        </table>
</div>

    </form>

<?php
//verificar se clicou no botao
if(isset($_POST['nome']))
{
    $nome = addslashes($_POST['nome']);
    $usuario= addslashes($_POST['usuario']);
    $senha= addslashes($_POST['senha']);
    $confSenh = ($_POST['confSenha']);   

    //verificar se esta preenchido
    if(!empty($nome) && !empty($usuario) && !empty($senha) && !empty($confSenh))
    {
        $u->conectar("carteira", "localhost", "root", "");
        if($u->msgErro == "")//se esta tudo certo
        {
            if($senha == $confSenh)
            {
                if($u->cadastrar($nome,$usuario,$senha))
                {
                    echo "cadastrado com sucesso! Acesse para entrar";
                }else{
                    echo "usuario já cadastrado";
                }
            }
            else
            {
                echo "Senha e confirmar senha não correspondem!";
            }
        }
        else
        {
            echo "Erro:".$u->msgErro;
        }
    }
    else
    {
        echo "preencha todos os campos!";
    }

}


?>
</body>
</head>
<html>