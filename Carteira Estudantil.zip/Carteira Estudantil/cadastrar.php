<?php
    require_once 'IMAGENS/CLASSES/usuario.php';
    $u = new usuario();

?>
<html lang="pt-br">
<head>
    <meta charset="utf-8/">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="CSS/estilo.css">
<body>
    <div id="corpo-form-cad">
    <h1>Cadastrar</h1>
    <form method="POST">
        <input type="text" name="nome" placeholder="Nome Completo" maxlength="100">
        <input type="text"name="usuario" placeholder="usuario" maxlength="100">
        <input type="password" name="senha" placeholder="Senha" maxlength="32">
        <input type="password" name="confSenha" placeholder="Confirmar Senha" maxlength="32">
        <input type="submit" value="Cadastrar">
        <a href = "login.php">Já é inscrito?<strong>LOGIN</strong>
        <a href="menu/menu.php"> voltar ao menu</a>
        

    </form>
</div>
<?php
//verificar se clicou no botao
if(isset($_POST['nome']))
{
    $nome = addslashes($_POST['nome']);
    $usuario= addslashes($_POST['usuario']);
    $senha= addslashes($_POST['senha']);
    $confSenh = ($_POST['confSenha']);   

    //verificar se esta preenchido
    if(!empty($nome) && !empty($usuario) && !empty($senha) && !empty($confSenh))
    {
        $u->conectar("carteira", "localhost", "root", "");
        if($u->msgErro == "")//se esta tudo certo
        {
            if($senha == $confSenh)
            {
                if($u->cadastrar($nome,$usuario,$senha))
                {
                    echo "cadastrado com sucesso! Acesse para entrar";
                }else{
                    echo "usuario já cadastrado";
                }
            }
            else
            {
                echo "Senha e confirmar senha não correspondem!";
            }
        }
        else
        {
            echo "Erro:".$u->msgErro;
        }
    }
    else
    {
        echo "preencha todos os campos!";
    }



}


?>
</body>
</head>
<html>