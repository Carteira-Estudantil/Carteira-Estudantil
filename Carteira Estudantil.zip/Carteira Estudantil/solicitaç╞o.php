<?php
    require_once 'IMAGENS/CLASSES/estudante.php';
    $u = new estudante();

?>
<html>
<head>
<title> </title>
</head>
<body>
</body>
</html>