<?php
//utilização de namespaces
namespace controle;
include 'processaAcesso.php';
use processaAcesso as processaAcesso;
$controle = new \processaAcesso\ProcessaAcesso;
if ($_POST['enviar']) {
    $login = $_POST['login'];
    $senha = md5($_POST['senha']);
    $usuario = $controle->verificaAcesso($login, $senha);
    //redirecionando para pagina conforme o tipo do usuário
    if ($usuario[0]['id_tipo_acesso'] == 1) {
        header("Location:paginas/pagina1.html");
    } else if ($usuario[0]['id_tipo_acesso'] == 2) {
        header("Location:paginas/pagina2.html");
    }
} else if ($_POST['cadastrar']) {
    $login = $_POST['login'];
    $senha = md5($_POST['senha']);
    $tipo_usuario = $_POST['tipo_usuario'];
    $arr = array('login_usuario' => $login, 'senha_usuario' => $senha,
'id_tipo_acesso' => $tipo_usuario);
    if (!$controle->cadastraUsuario($arr)) {
        echo 'Aconteceu algum erro';
    } else {
        $tipo_acesso = $controle->verificaAcesso($login, $senha);
        if ($tipo_acesso[0]['id_tipo_acesso'] == 1) {
            header("Location:paginas/pagina1.html");
        } else if ($tipo_acesso[0]['id_tipo_acesso'] == 2) {
            header("Location:paginas/pagina2.html");
        }
    }
}
?>













<?php
//utilização de namespaces
namespace processaAcesso {
include 'conexao/mysql.php';
    use Mysql as Mysql;
    class ProcessaAcesso {        
        var $db;
        public function __construct() {
            $conexao = new Mysql\mysql(DB_SERVER, DB_NAME, DB_USERNAME, DB_PASSWORD);
            $this->db = $conexao;
        }
        public function verificaAcesso($login, $senha) {            
            $select = $this->db->select('tb_usuario', '*',
" where login_usuario = '$login' and senha_usuario = '$senha'");
            return $select;
        }        
        public function cadastraUsuario($dados){            
            $insert = $this->db->insert('tb_usuario', $dados);
            return $insert;
        }
    }
}
?>

<?php
//utilização de namespaces
namespace Mysql {
    //declaração de variáres globais
    define('DB_SERVER', 'localhost');
    define('DB_NAME', 'acesso');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
 
    class mysql {
        var $db, $conn;
        public function __construct($server, $database, $username, $password) {
            $this->conn = mysql_connect($server, $username, $password);
            $this->db = mysql_select_db($database, $this->conn);
        }
        /**
         * Função de seleção dos registros da tabela
         * @param string $tabela tabela onde será buscado os registros
         * @param string $colunas string contendo as colunas separadas
por virgula para seleção, se null busca por todas *
         */
        public function select($tabela, $colunas = "*", $where = "1=1") {
            $sql = "SELECT $colunas FROM $tabela $where";
            $result = $this->executar($sql);
            while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
                $return[] = $row;
            }
            return $return;
        }
 
        /**
         * Função para inserir dados na tabela
         * @param array $dados Array contendo os dados a serem inseridos
         * @param string $tabela tabela que será inserido os dados
         * @return boolean verdadeiro ou falso
         */
        public function insert($tabela, $dados) {
 
            foreach ($dados as $key => $value) {
                $keys[] = $key;
                $insertvalues[] = '\'' . $value . '\'';
            }
            $keys = implode(',', $keys);
            $insertvalues = implode(',', $insertvalues);
            $sql = "INSERT INTO $tabela ($keys) VALUES ($insertvalues)";
            return $this->executar($sql);
        }
        private function executar($sql) {
            $return_result = mysql_query($sql, $this->conn);
            if ($return_result) {
                return $return_result;
            } else {
                $this->sql_error($sql);
            }
        }
        private function sql_error($sql) {
            echo mysql_error($this->conn) . '<br>';
            die('error: ' . $sql);
        }
    }
}
?>