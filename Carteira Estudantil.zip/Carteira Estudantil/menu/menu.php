<html lang="pt-br">
<head>
    <title>CARTEIRA ESTUDANTIL DIGITAL</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="estilomenu.css">
</head>
<body>
    <h1><center><font size="9"face="Courier New">CARTEIRA ESTUDANTIL DIGITAL</font></center></h1>
    <input type="checkbox" id="chec">
    <label for="chec">
        <img src="ic.jpg">
    </label>
    <nav>
        <ul>
            <li><a href=""> HOME</a></li>
            <li><a href="../cadastroestudante.php"> SOLICITAR CARTEIRAS</a></li>
            <li><a href=""> SOLICITAÇÃO DE CARTEIRAS</a></li>
            <li><a href="../login.php"> LOGIN</a></li>
        </ul>
    </nav>
   

</body>
</html>