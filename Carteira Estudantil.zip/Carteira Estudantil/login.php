<html lang ="pt-br">
<head>
<meta charset="utf-8/">
<title> Projeto Login </title>
<link rel = "stylesheet" href="CSS/estilo.css">
</head>
<body>
<div id ="corpo-form">
<h1> ENTRAR</h1>
<form method="POST">
<input type = "text" placeholder="Usuário"name = "usuario">
<input type = "password"placeholder="Senha" name = "senha">
<input type = "submit"value="ENTRAR">
<a href = "cadastrar.php">Ainda não é inscrito?<strong> Cadastre-se!</strong>
<a href="menu/menu.php"> voltar ao menu</a>

</form>
</div>
<?php

?>
</body>
</html>
